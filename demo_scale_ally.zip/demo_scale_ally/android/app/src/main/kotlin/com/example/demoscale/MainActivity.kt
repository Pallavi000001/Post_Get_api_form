package com.example.demoscale

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
