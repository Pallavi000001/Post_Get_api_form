package com.example.demo_scale_ally

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
