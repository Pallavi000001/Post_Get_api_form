
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'booking.dart';
import 'home.dart';
class Bottome extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Bottomee();
  }
}
class Bottomee extends State<Bottome> with SingleTickerProviderStateMixin {

  bool expanded = true;
  AnimationController controller;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    controller = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 400),
      reverseDuration: Duration(milliseconds: 400),
    );
  }
  static const TextStyle optionStyle =
  TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  Widget pages = Home();
  changePage(value) async {
    if (value == 0) {
      setState(() {
        pages = Home();
      });
    }
    if (value == 1) {
      setState(() {
        pages = Booking();
      });
    }

    if (value == 2) {
      setState(() {
        pages =  Booking();
      });
    }
    if (value == 3) {
      setState(() {
        pages =  Booking();
      });
    }
    if (value == 4) {
      setState(() {
        pages =  Booking();
      });
    }

  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(

      body: pages,
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _currentIndex,
        backgroundColor: Colors.white,
        selectedItemColor: Colors.pink,
        unselectedItemColor: Colors.black,
        onTap: (value) {
          changePage(value);
          controller.forward();
          setState(() => _currentIndex = value);
        },
        items: [
          BottomNavigationBarItem(
            title: Text('Home',style: TextStyle(fontSize:12)),
            icon: Icon(Icons.home_filled,size: 25),
          ),

          BottomNavigationBarItem(
            title: Text('Booking',style: TextStyle(fontSize: 12),),
            icon: Icon(Icons.fact_check,size: 25),
          ),

          BottomNavigationBarItem(
            title: Text('Nearby',style: TextStyle(fontSize: 12),),
            icon: Icon(Icons.location_on ,size: 25),
          ),
          BottomNavigationBarItem(
            title: Text('Message',style: TextStyle(fontSize: 12),),
            icon: Icon(Icons.message,size: 25),
          ),

          BottomNavigationBarItem(
            title: Text('Account',style: TextStyle(fontSize: 12),),
            icon: Icon(Icons.account_circle_rounded ,size: 25),
          ),
        ],
        showSelectedLabels: true,
        showUnselectedLabels: true,
      ),
    );
  }

}
