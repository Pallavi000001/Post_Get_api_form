class Formfillmodel {
  bool status;
  String message;
  Null errorCode;
  Null errorMsg;
  Data data;
  Null metaParams;

  Formfillmodel(
      {this.status,
        this.message,
        this.errorCode,
        this.errorMsg,
        this.data,
        this.metaParams});

  Formfillmodel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    errorCode = json['error_code'];
    errorMsg = json['error_msg'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
    metaParams = json['meta_params'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    data['error_code'] = this.errorCode;
    data['error_msg'] = this.errorMsg;
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    data['meta_params'] = this.metaParams;
    return data;
  }
}

class Data {
  int userId;
  String name;
  String email;
  String image;
  String dob;
  String gender;
  String userStatus;
  bool isNew;

  Data(
      {this.userId,
        this.name,
        this.email,
        this.image,
        this.dob,
        this.gender,
        this.userStatus,
        this.isNew});

  Data.fromJson(Map<String, dynamic> json) {
    userId = json['user_id'];
    name = json['name'];
    email = json['email'];
    image = json['image'];
    dob = json['dob'];
    gender = json['gender'];
    userStatus = json['user_status'];
    isNew = json['isNew'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['user_id'] = this.userId;
    data['name'] = this.name;
    data['email'] = this.email;
    data['image'] = this.image;
    data['dob'] = this.dob;
    data['gender'] = this.gender;
    data['user_status'] = this.userStatus;
    data['isNew'] = this.isNew;
    return data;
  }
}
