class Serviceslst {
  bool status;
  Message message;
  Null errorCode;
  Null errorMsg;
  List<Data> data;
  Null metaParams;

  Serviceslst(
      {this.status,
        this.message,
        this.errorCode,
        this.errorMsg,
        this.data,
        this.metaParams});

  Serviceslst.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message =
    json['message'] != null ? new Message.fromJson(json['message']) : null;
    errorCode = json['error_code'];
    errorMsg = json['error_msg'];
    if (json['data'] != null) {
      data = new List<Data>();
      json['data'].forEach((v) {
        data.add(new Data.fromJson(v));
      });
    }
    metaParams = json['meta_params'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.message != null) {
      data['message'] = this.message.toJson();
    }
    data['error_code'] = this.errorCode;
    data['error_msg'] = this.errorMsg;
    if (this.data != null) {
      data['data'] = this.data.map((v) => v.toJson()).toList();
    }
    data['meta_params'] = this.metaParams;
    return data;
  }
}

class Message {
  String eN;
  String hI;

  Message({this.eN, this.hI});

  Message.fromJson(Map<String, dynamic> json) {
    eN = json['EN'];
    hI = json['HI'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['EN'] = this.eN;
    data['HI'] = this.hI;
    return data;
  }
}

class Data {
  int id;
  Message name;
  String icon;
  Null banner;
  String bgcolor;

  Data({this.id, this.name, this.icon, this.banner, this.bgcolor});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'] != null ? new Message.fromJson(json['name']) : null;
    icon = json['icon'];
    banner = json['banner'];
    bgcolor = json['bgcolor'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    if (this.name != null) {
      data['name'] = this.name.toJson();
    }
    data['icon'] = this.icon;
    data['banner'] = this.banner;
    data['bgcolor'] = this.bgcolor;
    return data;
  }
}
