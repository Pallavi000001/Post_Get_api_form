
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
class  Poststate extends ChangeNotifier{
  var message = "";
  Future<bool> postUser(image,name,email,pas,newpass,gender,dob,status) async{
    bool retval = false;
    try{
      var url = "https://anaajapp.com/api/user/submit_details";
      var map = new Map<String,dynamic>();
    map['image'] = "salon.png";
    map['name'] = name;
    map['email'] = email;
    map['create_pass'] = pas;
    map['Confirm_pass'] = newpass;
    map['gender']= gender;
    map['dob']= dob;
      map['user_status']=status;
      var jdata = jsonEncode(map);
      debugPrint(jdata);
      http.Response res = await http.post(Uri.parse(url),body:map);

      debugPrint(res.body);
      if (json.decode(res.body)['status'] == true) {

        retval = true;
      } else  {
        message=json.decode(res.body)['error_msg'];
        debugPrint(message);

        retval = false;
      }
      return retval;

    }catch(e){
      print(e);
    }
    return retval;
  }

}