import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
class Booking extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Bookingg();
  }
}

class Bookingg extends State<Booking> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      backgroundColor: Colors.pink,
      body: Padding(
        padding: const EdgeInsets.all(19.0),
        child: Center(
            child: Column(
              children: <Widget>[
                Container(

                )
              ],
            ),
          ),
      ),

    );}}