import 'package:demo_scale_ally/model/post_state.dart';
import 'package:flutter/cupertino.dart';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart'as http;
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'model/servicelistapi.dart';
class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return   MultiProvider(
      providers: [
        ChangeNotifierProvider<Poststate>(
          create: (context) => Poststate(),
        ),
      ],
      child: Homes(),
    );
  }
}
class Homes extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Homee();
  }
}
class Homee extends State<Homes>{
  final _nameTextEditingController = TextEditingController();
  final _emailTextEditingController = TextEditingController();
  final _createpassTextEditingController = TextEditingController();
  final _confirmpassTextEditingController = TextEditingController();
  String radioButtonItem = 'Active';
  File _imageFile;
  var _images;
  var device;
  var base64Image;
  Future<void> captureImage(ImageSource imageSource) async {
    try {
      final imageFile = await ImagePicker.pickImage(source: imageSource);
      setState(() {
        _imageFile = imageFile;
        _images = File(_imageFile.path);

      });
    } catch (e) {
      print(e);
    }
  }
bool loading=false;
  _submit() async {
setState(() {
  loading=true;
});
    Poststate _postState = Provider.of<Poststate>(context, listen: false);
    try {
      if (await _postState.postUser(_images,
          _nameTextEditingController.text,
          _emailTextEditingController.text,
          _createpassTextEditingController.text,
          _confirmpassTextEditingController.text,
          _levelGender,
          getdateaa,
          radioButtonItem)) {
        setState(() {
          loading=false;
        });
      } else {
        var error = _postState.message;
        Fluttertoast.showToast(
            msg: error,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0
        );
        print(error);
        setState(() {
          loading=false;
        });
      }
    } catch (e) {
      print(e.toString());
    }
  }
  @override
  void initState() {
    Servicelist();
    super.initState();
  }
  DateTime selectedDateaa =  DateTime.now();
  DateTime initialdateaa = DateTime.now();
  String getdateaa = "";
  Future<void> _selectDateaa(BuildContext context) async {
    final DateTime picked = await showDatePicker(

      context: context,
      initialDate: initialdateaa,
      firstDate: DateTime(1960, 8),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != selectedDateaa) {
      setState(() {
        initialdateaa = picked;
        getdateaa = picked.day.toString() +
            "/" +
            picked.month.toString() +
            "/" +
            picked.year.toString();
      });
    }
    print(picked.year.toString() +
        "/" +
        picked.month.toString() +
        "/" +
        picked.day.toString());
  }
   bool _passwordVisible = false;
  bool _passwordVisibles = false;
  String _levelGender ="Select Gender";

  List<String> _list = [
    'Female',
    'Male',
  ];
  List<Data> data=[];
  int id = 1;
  Widget _buildImage() {
    if (_imageFile != null) {
      return Image.file(_imageFile);
    }
    else {
      return  Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(7.0),
            child:Container(
              height: MediaQuery.of(context).size.height*2.053,
              width: MediaQuery.of(context).size.width*4.546,

              decoration: BoxDecoration(
                borderRadius:
                BorderRadius.circular(23),
              ),
              child:  Container(
                width: MediaQuery.of(context).size.width*0.6,
                height:MediaQuery.of(context).size.height*.3,
                child:
                Image(image: AssetImage('assets/grey.png')),
              ),
            ),
          ),

          Center(
            child: Positioned(

              child: Container(
                padding: EdgeInsets.only(top:22),
                child: Text(
                  'Upload',
                  style: TextStyle(fontSize: 17, color: Colors.grey),
                ),
              ),
            ),
          ),
          Container(
            constraints: BoxConstraints.expand(height: 75.0),
            child: IconButton(
              icon: const Icon(Icons.camera_alt,color: Colors.grey,size: 25,),
              key: Key('retake'),
              onPressed: () => captureImage(ImageSource.gallery),
            ),
          ),

        ],
      );
    }
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
      appBar: AppBar(toolbarHeight: 0,
        backgroundColor: Colors.pink,
      ),
        body: SingleChildScrollView(
          child: Column(
            children: [
            Container(
            height: 90,
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
            gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
              colors: [
                Colors.indigo,
                Colors.deepPurple.shade300,
                Colors.pink,
               // Colors.deepPurple,
              ],
            )
            ),
          child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Row(
                mainAxisAlignment:MainAxisAlignment.spaceBetween,
                children: [
                  Container(
padding: EdgeInsets.only(left: 6),
                    width: 120,
                    height:10,
                    child:
                    Image(image: AssetImage('assets/lcn.png')),
                  ),

                  Container(
                    padding: EdgeInsets.only(right: 15,top: 5),
                    child:  Icon(Icons.notification_important,size: 25,color: Colors.white,),
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.only(left:9),
              child: Text("Pikashi Jain",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                  )
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 7,left: 7),
              child: Row(
                children: [
                  Container(
                    child: Icon(Icons.location_on_outlined,size: 15,color: Colors.white,),
                  ),
                  Container(
                    child: Text("Time Square Plaza, New York",
                        style: TextStyle(
                          color: Colors.white,
                        )
                    ),
                  ),
                  Container(
                    child:  Icon(Icons.keyboard_arrow_down_rounded,size: 20,color: Colors.white,),
                  ),
                ],
              ),
            ),
          ],
      ),
      ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                          padding: EdgeInsets.only(left: 5,top: 10),
                        child:Text("Highest Rated",
                        style: TextStyle(
                          color: Colors.deepPurple,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                        )
                      ),
                      Container(
                          padding: EdgeInsets.only(right: 8,top: 5),
                          child:Text("View all",
                            style: TextStyle(
                                color: Colors.deepPurple,
                               // fontWeight: FontWeight.bold,
                                fontSize: 15,
                            ),
                          )
                      )
                    ],
                  )
                ),
              ),
              Container(
                height: 220,
                child: ListView.builder(
                    itemCount:4,
                    shrinkWrap:true,
                    scrollDirection: Axis.horizontal,
                    itemBuilder:(BuildContext context,index){
                      return Container(
                        child: Column(
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.all(4.0),
                              child: Container(
                                  height:210,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.all(Radius.circular(13)),
                                      border: Border.all(color: Colors.black26)),
                                  child: Row(
                                    children: [
                                      Container(
                                        // color:Colors.red,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [

                                              Container(
                                                padding:EdgeInsets.only(left:5,right: 5),
                                                width: MediaQuery.of(context).size.width*0.5,
                                                height:120,
                                                //color: Colors.pink,
                                                //  padding: EdgeInsets.only(left: 15),
                                                child:
                                                Image(image: index ==0? AssetImage('assets/salon.png'):index ==1?AssetImage('assets/adam.png'):index==2?AssetImage('assets/salon.png'):AssetImage('assets/adam.png')),
                                              ),

                                            Padding(
                                              padding: const EdgeInsets.all(.04),
                                              child: Container(
                                                padding: EdgeInsets.only(left: 10),
                                                child: Text("Salon Name",
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 15,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.all(2.0),
                                              child: Container(
                                                padding: EdgeInsets.only(left: 8,bottom: 3,top: 3),
                                                child: Text("Near location Name",
                                                  style: TextStyle(
                                                    // fontWeight: FontWeight.bold,
                                                    fontSize: 14,
                                                  ),
                                                ),
                                              ),
                                            ),

                                            Container(
                                              width: MediaQuery.of(context).size.width*0.5,
                                              height: 25,

                                              child: Row(


                                                children: [
                                                  Flexible(
                                                    flex: 2,
                                                    child: Container(
                                                      padding: EdgeInsets.only(left: 7),
                                                      child: Row(
                                                        // mainAxisAlignment: MainAxisAlignment.start,
                                                        children: [
                                                          Container(

                                                            child: Icon(Icons.star,
                                                              size: 15,
                                                              color: Colors.orange
                                                              ,
                                                            ),
                                                          ),
                                                          Container(
                                                            child: Icon(Icons.star,
                                                              size: 15,
                                                              color: Colors.orange
                                                              ,
                                                            ),
                                                          ),
                                                          Container(
                                                            child: Icon(Icons.star,
                                                              size: 15,
                                                              color: Colors.orange
                                                              ,
                                                            ),
                                                          ),
                                                          Container(
                                                            child: Icon(Icons.star,
                                                              size: 15,
                                                              color: Colors.orange
                                                              ,
                                                            ),
                                                          ),
                                                          Container(
                                                            child: Icon(Icons.star,
                                                              size: 15,
                                                              color: Colors.orange
                                                              ,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Flexible(
                                                      flex: 1,
                                                      child:  Container(
                                                        // padding: EdgeInsets.only(left:15),
                                                        child: Row(
                                                          children: [
                                                            Container(
                                                              child: Icon(Icons.location_on_outlined,
                                                                size: 15,),
                                                            ),
                                                            Container(
                                                              child: Text("2 Mile",
                                                                style: TextStyle(
                                                                    color: Colors.blueGrey
                                                                ),
                                                              ),
                                                            )
                                                          ],
                                                        ),
                                                      )
                                                  )
                                                ],
                                              ),

                                            ),
                                          ],
                                        ),
                                      )
                                    ],
                                  )),
                            ),

                          ],
                        ),
                      );



                    } ),
              ),
              Container(
                  padding: EdgeInsets.only(left: 15,bottom: 15,right: 15,top: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                          child:Text("Services",
                            style: TextStyle(
                                color: Colors.deepPurple,
                                fontWeight: FontWeight.bold,
                                fontSize: 18
                            ),
                          )
                      ),
                      Container(
                          child:Text("View all",
                            style: TextStyle(
                              color: Colors.deepPurple,
                              // fontWeight: FontWeight.bold,
                              fontSize: 19,
                            ),
                          )
                      )
                    ],
                  )
              ),
             Container(
                    height: 120,
                    width: MediaQuery.of(context).size.width*1.0,
                    child: ListView.builder(

                        itemCount:data.length,
                        shrinkWrap:true,
                        //    physics: NeverScrollableScrollPhysics(),
                        scrollDirection: Axis.horizontal,
                        itemBuilder:(BuildContext context,index){
                          return Stack(
                            children: [
                               Padding(
                                 padding: const EdgeInsets.all(8.0),
                                 child: Container(

                                       width: MediaQuery.of(context).size.width*0.246,
                                       height: 100,
                                    padding: EdgeInsets.only(top: 0,right:5,left:5),
                                      decoration: BoxDecoration(
                                        color:Color(int.parse(data[index].bgcolor)),
                                        borderRadius:
                                        BorderRadius.circular(9),
                                      ),

                                         // padding: const EdgeInsets.all(15.0),
                                          child:Container(
                          child:Column(
                          children:[
                            Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: Container(
                                width: MediaQuery.of(context).size.width*0.246,
                                height: 50,
                                decoration: BoxDecoration(
                                  color: Color(int.parse(data[index].bgcolor)),
                                  borderRadius: BorderRadius.circular(50.0),
                                  image: DecorationImage(
                                    image:NetworkImage(data[index].icon)
                                    ,
                                    //fit: BoxFit.contain
                                  ),
                                ),
                              ),
                            ),
                            Center(
                              child: Container(
                                child: Text(
                                  'Woman Beautician',
                                  style: TextStyle(fontSize: 9, color: Colors.white),
                                ),
                              ),
                            ),
                          ]
                          )
                          )


                                      ),
                                    ),
                            ],
                          );

                        } ),
                  ),
              Padding(

                padding: const EdgeInsets.all(20.0),
                child: Container(
                  padding: EdgeInsets.only(top: 10,bottom: 10),
                  height: 2,
                  color: Colors.grey,
                ),
              ),

              Center(
                child: Container(
                    height:MediaQuery.of(context).size.height*0.146,
                   // width:MediaQuery.of(context).size.width*0.346,
                    child: Center(child: _buildImage())),
              ),
              Container(
                padding: EdgeInsets.only(top: 20, bottom: 5),
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                              border: Border.all(color: Colors.black12)),
                          child: Row(
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width*0.7,
                                child: TextField(
                                  autofocus: true,
                                  controller: _nameTextEditingController,
                                  decoration: InputDecoration(
                                      border: InputBorder.none,
                                      hintText: "Full Name",
                                      hintStyle:
                                      TextStyle(color:Colors.grey),
                                      contentPadding: EdgeInsets.only(
                                        left: 10,
                                      ),
                                      counterText: ""),
                                  keyboardType: TextInputType.text,

                                ),
                              ),
                            ],
                          )),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.only(top: 20, bottom: 5),
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                              border: Border.all(color: Colors.black12)),
                          child: Row(
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width*0.7,
                                child: TextField(
                                  autofocus: true,
                                  controller:  _emailTextEditingController,
                                  decoration: InputDecoration(
                                      border: InputBorder.none,
                                      hintText: "Enter your Email Id",
                                      hintStyle:
                                      TextStyle(color:Colors.grey),
                                      contentPadding: EdgeInsets.only(
                                        left: 10,
                                      ),
                                      counterText: ""),
                                  keyboardType: TextInputType.text,

                                ),
                              ),
                            ],
                          )),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.only(top: 20, bottom: 5),
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                              border: Border.all(color: Colors.black12)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width*0.7,
                                child: TextField(
                                  controller:  _createpassTextEditingController,
                                  autofocus: true,
                                  obscureText: !_passwordVisibles,
                                  //controller: category_description,
                                  decoration: InputDecoration(
                                      border: InputBorder.none,
                                      hintText: "create password",
                                      hintStyle:
                                      TextStyle(color:Colors.grey),
                                      contentPadding: EdgeInsets.only(
                                        left: 10,
                                      ),
                                      counterText: ""),
                                  keyboardType: TextInputType.text, //maxLength: 10,
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.only(left: 20),
                                child: IconButton(
                                  icon: Icon(
                                      _passwordVisibles
                                          ? Icons.visibility
                                          : Icons.visibility_off,
                                      color: Colors.grey
                                  ),
                                  onPressed: () {
                                    setState(() {
                                      _passwordVisibles = !_passwordVisibles;
                                    });
                                  },
                                ),
                              ),
                            ],
                          )),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.only(top: 20, bottom: 5),
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                              border: Border.all(color: Colors.black12)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width*0.7,
                                child: TextField(
                                  controller:  _confirmpassTextEditingController,
                                  autofocus: true,
                                  obscureText: !_passwordVisible,
                                  decoration: InputDecoration(
                                      border: InputBorder.none,
                                      hintText: "Confirm password",
                                      hintStyle:
                                      TextStyle(color:Colors.grey),
                                      contentPadding: EdgeInsets.only(
                                        left: 10,
                                      ),
                                      counterText: ""

                                  ),

                                  keyboardType: TextInputType.text,
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.only(left: 20),
                                child: IconButton(
                                  icon: Icon(
                                      _passwordVisible
                                          ? Icons.visibility
                                          : Icons.visibility_off,
                                      color: Colors.grey
                                  ),
                                  onPressed: () {
                                    setState(() {
                                      _passwordVisible = !_passwordVisible;
                                    });
                                  },
                                ),
                              ),
                            ],
                          )),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.only(top: 20, bottom: 5),
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: Container(
                       padding: EdgeInsets.only(left: 10,right: 10),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                              border: Border.all(color: Colors.black12)),
                          child:  DropdownButton(
                            onChanged: (val){
                              print(val);
                              setState(() {
                                _levelGender =  _list[int.parse(val.toString())].toString();
                              });
                            },
                            hint: Text(_levelGender,

                              style: GoogleFonts.poppins(
                                fontSize: 16,
                                fontWeight: FontWeight.w400,
                                height: 1.5,
                                letterSpacing: .5,
                                color:  _levelGender =="Select Gender"?Colors.grey:Colors.black,
                              ),
                            ),
                            style: TextStyle(),
                            underline: Container(
                              height: 0,
                            ),
                            isExpanded: true,
                            icon: Icon(

                              Icons.keyboard_arrow_down_rounded,color: Colors.grey,
                            ),
                            items: List.generate(_list.length,

                                    (index){
                                  return DropdownMenuItem(
                                    value: index.toString(),
                                    child: Text(
                                      _list[
                                      index]
                                          .toString(),
                                      style: TextStyle(
                                          color: Colors.black
                                      ),
                                    ),
                                  );
                                }),
                          ),),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                  ],
                ),
              ),
              InkWell(
                onTap: (){
                  _selectDateaa(context);
                },
                child: Container(
                  padding: EdgeInsets.only(top: 20, bottom: 5),
                  child: Column(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10.0),
                        child: Container(
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.all(Radius.circular(10)),
                                border: Border.all(color: Colors.black12)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [

                                Container(
                                  width: MediaQuery.of(context).size.width*0.7,
                                  child: TextField(
                                    autofocus: true,
                                    readOnly: true,
                                    onTap: (){
                                      _selectDateaa(context);
                                    },
                                    decoration: InputDecoration(
                                        border: InputBorder.none,
                                        hintText: getdateaa ==""?"Date of Birth":getdateaa,
                                        hintStyle:
                                        TextStyle(
                                          color: getdateaa =="Female"?Colors.black:getdateaa =="Male"?Colors.black:Colors.grey,
                                        ),
                                        contentPadding: EdgeInsets.only(
                                          left: 10,
                                        ),
                                        counterText: ""),
                                    keyboardType: TextInputType.text,

                                  ),
                                ),
                                Container(
                                  padding: EdgeInsets.only(right: 10),
                                  child: Icon(
                                    Icons.date_range_rounded,
                                    color:Colors.grey,
                                  ),
                                ),
                              ],
                            )),
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                    ],
                  ),
                ),
              ),
          Column(
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                Container(
                  padding: EdgeInsets.only(right: 18,bottom: 10,top: 5),
                  child: Row(
                    children: [
                      Radio(
                        value: 1,activeColor: Colors.pink,
                        groupValue: id,
                        onChanged: (val) {
                          setState(() {
                            radioButtonItem  = 'Active';
                            id = 1;
                          });
                        },
                      ),
                      Text(
                        'Active',
                        style: new TextStyle(fontSize: 17.0),
                      ),
                    ],
                  ),
                ),


                  Radio(
                    value: 2,
                    groupValue: id,
                    activeColor: Colors.pink,
                    onChanged: (val) {
                      setState(() {
                        radioButtonItem = 'Suspended';
                        id = 2;
                      });
                    },
                  ),
                  Text(
                    'Suspended',
                    style: new TextStyle(
                      fontSize: 17.0,
                    ),
                  ),
                ],
              ),
            ],
          ),

              Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height*.0717,
                padding: EdgeInsets.only(left: 10, right: 10,bottom: 20),
                child: Material(
                  color:Colors.deepPurple,
                  borderRadius: BorderRadius.all(Radius.circular(15)),
                  child: InkWell(
                    onTap: () async{
                      if(_nameTextEditingController.text.isEmpty){
                      }
                      _submit();
                    },
                    child: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                      height: 60,
                      child: Stack(
                        children: [
                          Container(
                            child: Center(
                                child: Text( loading==true?"Loading":"Submit",style: TextStyle(fontSize: 15,color: Colors.white,))
                            ),
                          ),

                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        )));}
  Future<dynamic> Servicelist() async {
    var url = 'https://anaajapp.com/api/categories';
    try {
      final http.Response response = await http.get(
        Uri.parse(url),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',

        },
      );

      return _returnLiveResponse(response);
    } on SocketException catch (_) {
      print('NetWork Connection Error');
      return;
    } catch (e) {

    }
  }
  dynamic _returnLiveResponse(http.Response response) async {
    var responseJson = Serviceslst.fromJson(jsonDecode(response.body));
    switch (response.statusCode) {
      case 200:
        if(mounted){
          setState(() {
            data = responseJson.data;

          });
        }
        print(
            '------------------------ success list---------------------------');
        return responseJson;
      default:

    }
  }}